<?php include "head.nav.php" ?>
		<?php include "user/register.php" ?>

		<!-- Footer -->
<?php include "footer.php" ?>
