<?php include "server.php" ?>

<div class="container">

<?php include "components/alert_messages.php"; ?>

<body>

<form method="POST">
	<div class="form-group">
		<align= center>
		<div class="auto">
		<label for="first_name">Nome<font color="red">*</font></label>
		<input class="form-control" type="text" name="first_name" id="first_name" value="<?php echo $first_name ?>">
	</div>
	<div class="form-group">
		<label for="last_name">Sobrenome<font color="red">*</font></label>
		<input class="form-control" type="text" name="last_name" id="last_name" value="<?php echo $last_name ?>">
	</div>
	<div class="form-group">
		<label for="phone">Тelefone<font color="red">*</font></label>
		<input class="form-control" type="number" name="phone" id="phone" value="<?php echo $phone ?>">
	</div>
	<div class="form-group">
		<label for="email">E-mail<font color="red">*</font></label>
		<input class="form-control" type="email" name="email" id="email" value="<?php echo $email ?>">
	</div>
	<div class="form-group">
		<label for="address">Endereço</label>
		<textarea class="form-control" id="address" name="address" placeholder="Cidade, endereço, ..."><?php echo $address; ?></textarea>
		<small id="emailHelp" class="form-text text-muted">Pode ser preenchido mais tarde.</small>
	</div>
	<div class="form-group">
		<label for="password">Senha<font color="red">*</font></label>
		<input class="form-control" type="password" name="password" id="password">
	</div>
	<div class="form-group">
		<label for="password_confirm">Confirme sua Senha<font color="red">*</font></label>
		<input class="form-control" type="password" name="password_confirm" id="password_confirm">
	</div>
	<button class="btn btn-secondary form-control" type="submit" name="register">Registrar</button>

</form>

</div>